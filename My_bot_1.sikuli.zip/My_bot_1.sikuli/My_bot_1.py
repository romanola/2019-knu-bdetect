setFindFailedResponse(SKIP)
import random as rd
import math

def start():
    click(Pattern("1548277925497.png").similar(0.94))
    
    

def getPause():
    pauses = [1,2,3,4,5,6]
    pause = rd.sample(pauses,1)
    return pause[0]


def heroPossition():
    x = 793
    y = 364
    return x, y


def check():
    return exists(Pattern("1548273774331.png").similar(0.68).targetOffset(5,0)) or exists(Pattern("1548273814743.png").similar(0.50))

def findNearest():
    coins = findAll(Pattern("1548275201363.png").similar(0.67))
    monsters = findAll(Pattern("1548275266128.png").similar(0.50))
    possibleItems = []
    for i in coins:
        possibleItems.append((i.getX,i.getY))
    for i in monsters:
        possibleItems.append((i.getX,i.getY))

    X,Y = heroPossition()
    possibleItems.sort(key=lambda x: math.sqrt((X - x[0])**2 + (Y - x[1])**2))
    res = possibleItems[0]
    return res.getX, res.getY

def randomMove():
    click(Location(rd.randrange(200), rd.randrange(200)))


def move():
    if check():
        click(Location(findNearest()))
    else:
        randomMove()

def main():
    start()
    while True:
        move()
        sleep(getPause())
   

main()
    
    





        
    
        